import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-IAKDBJQ6.js";
import "./chunk-ELZW3FO3.js";
import "./chunk-2SJ2DHYL.js";
import "./chunk-7IZA5DSI.js";
import "./chunk-MZI5CNUD.js";
import "./chunk-U5R4ADIY.js";
import "./chunk-7GX5645L.js";
import "./chunk-WDMUDEB6.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
