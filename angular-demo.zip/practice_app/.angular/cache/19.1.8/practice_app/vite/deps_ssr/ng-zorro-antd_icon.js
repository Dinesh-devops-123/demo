import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-G7AK36MF.js";
import "./chunk-5KDQREHF.js";
import "./chunk-5IOQIXFC.js";
import "./chunk-TES4JXVL.js";
import "./chunk-IUKGO5CI.js";
import "./chunk-C5KUQ6XX.js";
import "./chunk-Z5IWENK5.js";
import "./chunk-YHCV7DAQ.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
